<?php

namespace Drupal\Core\File\Exception;

/**
 * Base class for exceptions related to file handling operations.
 */
class FileException extends \RuntimeException {
}
