<?php

namespace Drupal\Core\File\Exception;

/**
 * Exception thrown when file cannot be written to disk.
 */
class FileWriteException extends FileException {
}
